import{_ as e,b as c,c as n}from"./index-CYVsF3cG.js";const r={};function t(o,s){return c(),n("div",null,"健身模块")}const a=e(r,[["render",t]]);export{a as default};
